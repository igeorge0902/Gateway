/* App Module */

var myApp = angular.module('myApp', [

  'myAppControllers',
  'myAppDirectives',
  'ui.bootstrap.m'
]);