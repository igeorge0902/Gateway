#SQL scripts
----

##contents
----
- truncate.sql - a clears devices from the dB.

###dump sql scripts
----
- a full dump of my working dB.
- use the most recent one!