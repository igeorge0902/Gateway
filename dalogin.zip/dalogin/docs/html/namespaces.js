var namespaces =
[
    [ "com", "namespacecom.html", "namespacecom" ]
];