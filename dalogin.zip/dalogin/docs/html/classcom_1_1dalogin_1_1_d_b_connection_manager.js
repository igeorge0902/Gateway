var classcom_1_1dalogin_1_1_d_b_connection_manager =
[
    [ "DBConnectionManager", "classcom_1_1dalogin_1_1_d_b_connection_manager.html#ababd94588891ef6b9ba6ce6aa06b87e7", null ],
    [ "closeConnection", "classcom_1_1dalogin_1_1_d_b_connection_manager.html#a525be4a64e02f21c1b4bd1d53ca73cc0", null ],
    [ "getConnection", "classcom_1_1dalogin_1_1_d_b_connection_manager.html#a36917ade7183181ab00d32c126915db7", null ]
];