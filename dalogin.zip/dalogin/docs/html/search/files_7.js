var searchData=
[
  ['memory_2ejava',['Memory.java',['../_memory_8java.html',1,'']]],
  ['mqrecieve_2ejava',['MQRecieve.java',['../_m_q_recieve_8java.html',1,'']]],
  ['mqsend_2ejava',['MQSend.java',['../_m_q_send_8java.html',1,'']]]
];
