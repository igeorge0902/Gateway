var searchData=
[
  ['dbconnectionmanager',['DBConnectionManager',['../classcom_1_1dalogin_1_1_d_b_connection_manager.html',1,'com::dalogin']]]
];
