var searchData=
[
  ['memory',['Memory',['../classcom_1_1dalogin_1_1utils_1_1_memory.html',1,'com::dalogin::utils']]],
  ['mqrecieve',['MQRecieve',['../classcom_1_1dalogin_1_1utils_1_1_m_q_recieve.html',1,'com::dalogin::utils']]],
  ['mqsend',['MQSend',['../classcom_1_1dalogin_1_1utils_1_1_m_q_send.html',1,'com::dalogin::utils']]]
];
