var searchData=
[
  ['jsonparser',['jsonParser',['../classcom_1_1dalogin_1_1utils_1_1json_parser.html',1,'com::dalogin::utils']]]
];
