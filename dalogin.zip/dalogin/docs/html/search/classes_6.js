var searchData=
[
  ['loggingout',['Loggingout',['../classcom_1_1dalogin_1_1_loggingout.html',1,'com::dalogin']]]
];
