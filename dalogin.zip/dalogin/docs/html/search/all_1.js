var searchData=
[
  ['base64',['base64',['../classcom_1_1dalogin_1_1utils_1_1_aes_util.html#abf9788d9b22764a48f2b42061952ac20',1,'com.dalogin.utils.AesUtil.base64(byte[] bytes)'],['../classcom_1_1dalogin_1_1utils_1_1_aes_util.html#ae84ca963c2b9528e8f57e791d4d7676e',1,'com.dalogin.utils.AesUtil.base64(String str)']]],
  ['bytestomegabytes',['bytesToMegabytes',['../classcom_1_1dalogin_1_1utils_1_1_memory.html#a8d329f13031034168f6dc9a233e38d63',1,'com::dalogin::utils::Memory']]]
];
