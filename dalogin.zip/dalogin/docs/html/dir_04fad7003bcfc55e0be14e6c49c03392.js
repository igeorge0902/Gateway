var dir_04fad7003bcfc55e0be14e6c49c03392 =
[
    [ "dalogin", "dir_31c2b0be595e792db6d2526a056c351f.html", "dir_31c2b0be595e792db6d2526a056c351f" ],
    [ "websocket", "dir_9fb7d9bba0f84c66a6a10d5558ea7af7.html", "dir_9fb7d9bba0f84c66a6a10d5558ea7af7" ]
];