//
//  r.swift
//  SwiftLoginScreen
//
//  Created by Gaspar Gyorgy on 18/11/15.
//  Copyright © 2015 Dipin Krishna. All rights reserved.
//

import Foundation

extension URLRequest {
    
    /// Helper for making a URL request.
    /// JSON encodes parameters if any are provided. You may want to change this if your server uses, say, XML.
        
    static func requestWithURL(_ URL: URL, method: String, queryParameters: [String: String]?, bodyParameters: NSDictionary?, headers: [String: String]?, cachePolicy: URLRequest.CachePolicy?, timeoutInterval: TimeInterval?) -> URLRequest {

        // If there's a querystring, append it to the URL.
        let actualURL: Foundation.URL
      
        if let queryParameters = queryParameters {
        
            var components = URLComponents(url: URL, resolvingAgainstBaseURL: true)!
            components.queryItems = queryParameters.map { (key, value) in URLQueryItem(name: key, value: value) }
            
            actualURL = components.url!
        
        } else {
            actualURL = URL
        }
        
        // Make the request for the given method.
        let request = NSMutableURLRequest(url: actualURL)
        request.httpMethod = method
        
        // Add any body JSON params (for POSTs).
        if let bodyParameters = bodyParameters {
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = try? JSONSerialization.data(withJSONObject: bodyParameters, options: [])
        }
        
        // Add any extra headers if given.
        if let headers = headers {
            for (field, value) in headers {
                request.addValue(value, forHTTPHeaderField: field)
            }
        }
        
        return request as URLRequest
    }
    
}
