//
//  CachedURLResponse.swift
//  SwiftLoginScreen
//
//  Created by Gaspar Gyorgy on 15/11/15.
//  Copyright © 2015 Dipin Krishna. All rights reserved.
//

import Foundation
import CoreData


class CachedURLResponse: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
