//
//  People.swift
//  SwiftLoginScreen
//
//  Created by Gaspar Gyorgy on 16/11/15.
//  Copyright © 2015 Dipin Krishna. All rights reserved.
//

import Foundation
import CoreData


class People: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
